package com.arachne.ai.voice

import com.arachne.ai.core.ModelManager
import com.arachne.ai.core.VoiceLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

class VoiceEngine(private val models: ModelManager) {

    private var voskModel: Model? = null
    private var activeLanguage: VoiceLanguage? = null
    private var speechService: SpeechService? = null
    private var partial = ""

    val isListening: Boolean
        get() = speechService != null

    suspend fun start(
        language: VoiceLanguage,
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        if (!models.voiceReady(language)) {
            onError("VOICE_MODEL_MISSING")
            return@withContext
        }

        stopInternal()

        if (activeLanguage != language || voskModel == null) {
            voskModel?.close()
            voskModel = Model(models.voiceModelDir(language).absolutePath)
            activeLanguage = language
        }

        partial = ""
        val recognizer = Recognizer(voskModel, 16000.0f)
        val service = SpeechService(recognizer, 16000.0f)
        speechService = service

        service.startListening(object : RecognitionListener {
            override fun onPartialResult(hypothesis: String?) {
                val text = parse(hypothesis, "partial")
                if (text.isNotBlank()) {
                    partial = text
                    onPartial(text)
                }
            }

            override fun onResult(hypothesis: String?) {
                val text = parse(hypothesis, "text")
                if (text.isNotBlank()) {
                    partial = text
                    onPartial(text)
                }
            }

            override fun onFinalResult(hypothesis: String?) {
                val text = parse(hypothesis, "text").ifBlank { partial }
                cleanupSpeech()
                if (text.isNotBlank()) onFinal(text)
                else onError("NO_SPEECH")
            }

            override fun onError(exception: Exception?) {
                cleanupSpeech()
                onError(exception?.message ?: "VOICE_ERROR")
            }

            override fun onTimeout() {
                val text = partial
                cleanupSpeech()
                if (text.isNotBlank()) onFinal(text)
                else onError("NO_SPEECH")
            }
        }, 12_000)
    }

    fun stop() {
        speechService?.stop()
    }

    private fun stopInternal() {
        try {
            speechService?.cancel()
            speechService?.shutdown()
        } catch (_: Exception) {
        }
        speechService = null
    }

    private fun cleanupSpeech() {
        try {
            speechService?.shutdown()
        } catch (_: Exception) {
        }
        speechService = null
    }

    private fun parse(json: String?, key: String): String {
        if (json.isNullOrBlank()) return ""
        return try {
            JSONObject(json).optString(key, "").trim()
        } catch (_: Exception) {
            ""
        }
    }

    fun release() {
        stopInternal()
        try {
            voskModel?.close()
        } catch (_: Exception) {
        }
        voskModel = null
    }
}

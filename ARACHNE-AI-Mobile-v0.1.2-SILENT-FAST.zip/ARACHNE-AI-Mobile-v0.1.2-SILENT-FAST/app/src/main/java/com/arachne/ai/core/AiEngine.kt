package com.arachne.ai.core

import android.content.Context
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import dev.ffmpegkit.llama.LlamaModel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class InferenceMode(val title: String) {
    FAST("Fast"),
    DEEP("Deep")
}

data class AiReply(
    val text: String,
    val tokensPerSecond: Float
)

class AiEngine(
    private val context: Context,
    private val memory: MemoryStore,
    private val models: ModelManager
) {
    private val mutex = Mutex()
    private var loadedModel: LlamaModel? = null

    suspend fun unload() = mutex.withLock {
        loadedModel?.let(Llama::releaseModel)
        loadedModel = null
    }

    private suspend fun ensureLoaded(): LlamaModel {
        loadedModel?.takeIf { it.isLoaded }?.let { return it }

        if (!models.aiReady()) error("LOCAL_MODEL_MISSING")

        // Mobile-first profile for Helio G99 class devices.
        val config = LlamaConfig(
            contextSize = 1024,
            threads = 4,
            gpuLayers = 0,
            temperature = 0.70f,
            topP = 0.80f,
            topK = 20
        )

        return Llama.loadModel(
            models.aiModelFile().absolutePath,
            config
        ).also { loadedModel = it }
    }

    suspend fun reply(
        userText: String,
        personality: Personality,
        mode: InferenceMode = InferenceMode.FAST
    ): AiReply = mutex.withLock {
        val model = ensureLoaded()

        val memories = memory.relevantMemories(userText, 3)
        val recent = memory.recentMessages(4)

        val memoryBlock =
            if (memories.isEmpty()) "none"
            else memories.joinToString(" | ") { it.text.take(140) }

        val historyBlock =
            if (recent.isEmpty()) "none"
            else recent.joinToString("\n") {
                "${it.role}: ${it.text.take(180)}"
            }

        // Qwen3 soft switch. FAST always puts /no_think LAST so it wins.
        val switch = if (mode == InferenceMode.FAST) "/no_think" else "/think"

        val systemPrompt = """
            ${personality.prompt}
            Relevant memories: $memoryBlock
            Recent chat:
            $historyBlock
        """.trimIndent()

        val finalPrompt = """
            $userText

            IMPORTANT: Give only the final answer. Never print analysis,
            reasoning, scratchpad, or <think> blocks.
            $switch
        """.trimIndent()

        val result = Llama.complete(
            model = model,
            prompt = finalPrompt,
            systemPrompt = systemPrompt,
            maxTokens = if (mode == InferenceMode.FAST) 120 else 220
        )

        AiReply(
            text = sanitizeFinalAnswer(result.text),
            tokensPerSecond = result.tokensPerSecond
        )
    }

    companion object {
        fun sanitizeFinalAnswer(raw: String): String {
            var text = raw.trim()

            // Remove every complete think block.
            text = text.replace(
                Regex("""(?is)<think\b[^>]*>.*?</think\s*>"""),
                ""
            ).trim()

            // Remove malformed/unclosed think block if one leaks.
            val open = text.indexOf("<think", ignoreCase = true)
            if (open >= 0) {
                val close = text.indexOf("</think>", open, ignoreCase = true)
                text = if (close >= 0) {
                    (text.substring(0, open) +
                        text.substring(close + 8)).trim()
                } else {
                    // If it starts with an unfinished reasoning block,
                    // never expose it to the UI.
                    text.substring(0, open).trim()
                }
            }

            // Defensive removal of common reasoning labels.
            text = text.replace(
                Regex("""(?im)^\s*(analysis|reasoning|scratchpad)\s*:\s*.*$"""),
                ""
            ).trim()

            return text
        }
    }
}

package com.arachne.ai.core

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class MemoryItem(
    val id: Long,
    val text: String,
    val createdAt: Long
)

data class StoredMessage(
    val role: String,
    val text: String,
    val createdAt: Long
)

class MemoryStore(context: Context) :
    SQLiteOpenHelper(context, "arachne_memory.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE memories(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE messages(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL,
                text TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    @Synchronized
    fun addMemory(text: String): Long {
        val v = ContentValues().apply {
            put("text", text.trim())
            put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insert("memories", null, v)
    }

    @Synchronized
    fun deleteMemory(id: Long) {
        writableDatabase.delete("memories", "id=?", arrayOf(id.toString()))
    }

    @Synchronized
    fun clearConversation() {
        writableDatabase.delete("messages", null, null)
    }

    @Synchronized
    fun addMessage(role: String, text: String) {
        val v = ContentValues().apply {
            put("role", role)
            put("text", text)
            put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insert("messages", null, v)
    }

    @Synchronized
    fun allMemories(limit: Int = 100): List<MemoryItem> {
        val out = mutableListOf<MemoryItem>()
        readableDatabase.query(
            "memories",
            arrayOf("id", "text", "created_at"),
            null, null, null, null,
            "created_at DESC",
            limit.toString()
        ).use { c ->
            while (c.moveToNext()) {
                out += MemoryItem(c.getLong(0), c.getString(1), c.getLong(2))
            }
        }
        return out
    }

    @Synchronized
    fun recentMessages(limit: Int = 10): List<StoredMessage> {
        val out = mutableListOf<StoredMessage>()
        readableDatabase.rawQuery(
            """
            SELECT role, text, created_at
            FROM (
                SELECT role, text, created_at, id
                FROM messages
                ORDER BY id DESC
                LIMIT ?
            )
            ORDER BY id ASC
            """.trimIndent(),
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out += StoredMessage(c.getString(0), c.getString(1), c.getLong(2))
            }
        }
        return out
    }

    fun relevantMemories(query: String, limit: Int = 6): List<MemoryItem> {
        val tokens = query.lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 3 }
            .toSet()

        if (tokens.isEmpty()) return allMemories(limit)

        return allMemories(150)
            .map { memory ->
                val lower = memory.text.lowercase()
                val score = tokens.count { lower.contains(it) }
                memory to score
            }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(limit)
            .map { it.first }
    }

    fun findMemories(query: String, limit: Int = 10): List<MemoryItem> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return emptyList()
        return allMemories(150)
            .filter { it.text.lowercase().contains(q) }
            .take(limit)
    }
}

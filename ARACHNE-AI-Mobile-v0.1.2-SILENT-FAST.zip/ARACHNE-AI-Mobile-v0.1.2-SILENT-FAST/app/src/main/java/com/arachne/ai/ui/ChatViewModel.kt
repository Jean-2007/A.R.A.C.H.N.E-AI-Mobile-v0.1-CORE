package com.arachne.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arachne.ai.core.*
import com.arachne.ai.voice.TtsEngine
import com.arachne.ai.voice.VoiceEngine
import com.arachne.ai.voice.VoiceStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatBubble(
    val role: String,
    val text: String
)

data class UiState(
    val messages: List<ChatBubble> = listOf(
        ChatBubble(
            "assistant",
            "A.R.A.C.H.N.E local core ready. Download the AI model in LAB to begin."
        )
    ),
    val personality: Personality = Personality.ARACHNE,
    val inferenceMode: InferenceMode = InferenceMode.FAST,
    val busy: Boolean = false,
    val status: String = "LOCAL CORE",
    val tokensPerSecond: Float = 0f,
    val aiReady: Boolean = false,
    val download: DownloadProgress? = null,
    val voiceLanguage: VoiceLanguage = VoiceLanguage.ES,
    val listening: Boolean = false,
    val voicePartial: String = "",
    val voiceStyle: VoiceStyle = VoiceStyle.CORE,
    val voiceOutput: Boolean = true,
    val memories: List<MemoryItem> = emptyList()
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val memory = MemoryStore(app)
    private val models = ModelManager(app)
    private val ai = AiEngine(app, memory, models)
    private val tts = TtsEngine(app)
    private val voice = VoiceEngine(models)

    private val _state = MutableStateFlow(
        UiState(aiReady = models.aiReady())
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        models.cleanupLegacyModels()
        refreshMemories()
        loadConversationPreview()
    }

    private fun loadConversationPreview() {
        val stored = memory.recentMessages(20)
        if (stored.isNotEmpty()) {
            _state.value = _state.value.copy(
                messages = stored.map { ChatBubble(it.role, it.text) }
            )
        }
    }

    fun setPersonality(value: Personality) {
        _state.value = _state.value.copy(personality = value)
    }

    fun setInferenceMode(value: InferenceMode) {
        _state.value = _state.value.copy(inferenceMode = value)
    }

    fun setVoiceLanguage(value: VoiceLanguage) {
        _state.value = _state.value.copy(voiceLanguage = value)
    }

    fun setVoiceStyle(value: VoiceStyle) {
        tts.setStyle(value)
        _state.value = _state.value.copy(voiceStyle = value)
    }

    fun toggleVoiceOutput() {
        val enabled = !_state.value.voiceOutput
        if (!enabled) tts.stop()
        _state.value = _state.value.copy(voiceOutput = enabled)
    }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isBlank() || _state.value.busy) return

        append("user", clean)
        memory.addMessage("user", clean)

        handleMemoryCommand(clean)?.let { directReply ->
            append("assistant", directReply)
            memory.addMessage("assistant", directReply)
            speakIfEnabled(directReply)
            return
        }

        if (!models.aiReady()) {
            val msg = "The local AI model is not installed yet. Open LAB and download Local Core."
            append("assistant", msg)
            return
        }

        _state.value = _state.value.copy(
            busy = true,
            status = "THINKING // ON DEVICE"
        )

        viewModelScope.launch {
            try {
                val result = ai.reply(clean, _state.value.personality, _state.value.inferenceMode)
                val reply = AiEngine.sanitizeFinalAnswer(result.text)
                    .ifBlank { "No pude generar una respuesta final. Inténtalo otra vez." }

                memory.addMessage("assistant", reply)
                append("assistant", reply)

                _state.value = _state.value.copy(
                    busy = false,
                    status = "LOCAL CORE // READY",
                    tokensPerSecond = result.tokensPerSecond
                )

                speakIfEnabled(reply)
            } catch (e: Throwable) {
                val msg = when {
                    e.message?.contains("LOCAL_MODEL_MISSING") == true ->
                        "Local model missing."
                    else -> "Local inference error: ${e.message ?: e.javaClass.simpleName}"
                }
                append("assistant", msg)
                _state.value = _state.value.copy(
                    busy = false,
                    status = "CORE ERROR"
                )
            }
        }
    }

    private fun handleMemoryCommand(text: String): String? {
        val trimmed = text.trim()

        val rememberPatterns = listOf(
            Regex("""(?i)^(?:recuerda|acuérdate|acuerdate)(?:\s+de)?(?:\s+que)?\s+(.+)$"""),
            Regex("""(?i)^remember(?:\s+that)?\s+(.+)$"""),
            Regex("""(?i)^(?:merk dir|erinnere dich(?: daran)?(?:,? dass)?)\s+(.+)$""")
        )

        rememberPatterns.forEach { pattern ->
            val match = pattern.find(trimmed)
            val fact = match?.groupValues?.getOrNull(1)?.trim()
            if (!fact.isNullOrBlank()) {
                memory.addMemory(fact)
                refreshMemories()
                return when (_state.value.voiceLanguage) {
                    VoiceLanguage.DE -> "Gespeichert."
                    VoiceLanguage.EN -> "Remembered."
                    VoiceLanguage.ES -> "Guardado en mi memoria local."
                }
            }
        }

        val forgetPatterns = listOf(
            Regex("""(?i)^(?:olvida|borra de tu memoria)\s+(.+)$"""),
            Regex("""(?i)^forget\s+(.+)$"""),
            Regex("""(?i)^(?:vergiss|lösche aus deinem gedächtnis)\s+(.+)$""")
        )

        forgetPatterns.forEach { pattern ->
            val match = pattern.find(trimmed)
            val query = match?.groupValues?.getOrNull(1)?.trim()
            if (!query.isNullOrBlank()) {
                val found = memory.findMemories(query, 5)
                found.forEach { memory.deleteMemory(it.id) }
                refreshMemories()
                return if (found.isEmpty()) {
                    "I could not find a matching stored memory."
                } else {
                    "Removed ${found.size} matching memory item(s)."
                }
            }
        }

        return null
    }

    private fun speakIfEnabled(text: String) {
        if (_state.value.voiceOutput) tts.speak(text)
    }

    private fun append(role: String, text: String) {
        _state.value = _state.value.copy(
            messages = (_state.value.messages + ChatBubble(role, text)).takeLast(60)
        )
    }

    fun startOrStopListening() {
        if (_state.value.busy) return

        if (voice.isListening) {
            voice.stop()
            return
        }

        // Barge-in: tapping the mic immediately stops A.R.A.C.H.N.E speaking.
        tts.stop()

        val lang = _state.value.voiceLanguage
        if (!models.voiceReady(lang)) {
            _state.value = _state.value.copy(
                status = "VOICE PACK MISSING // ${lang.title}"
            )
            return
        }

        _state.value = _state.value.copy(
            listening = true,
            voicePartial = "",
            status = "LISTENING // ${lang.title.uppercase()}"
        )

        viewModelScope.launch {
            voice.start(
                language = lang,
                onPartial = { partial ->
                    _state.value = _state.value.copy(voicePartial = partial)
                },
                onFinal = { finalText ->
                    _state.value = _state.value.copy(
                        listening = false,
                        voicePartial = "",
                        status = "VOICE CAPTURED"
                    )
                    send(finalText)
                },
                onError = { error ->
                    _state.value = _state.value.copy(
                        listening = false,
                        voicePartial = "",
                        status = "VOICE ERROR // $error"
                    )
                }
            )
        }
    }

    fun addMemory(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        memory.addMemory(clean)
        refreshMemories()
    }

    fun deleteMemory(id: Long) {
        memory.deleteMemory(id)
        refreshMemories()
    }

    fun clearConversation() {
        memory.clearConversation()
        _state.value = _state.value.copy(
            messages = listOf(
                ChatBubble("assistant", "Conversation cleared. Long-term memory was kept.")
            )
        )
    }

    private fun refreshMemories() {
        _state.value = _state.value.copy(memories = memory.allMemories())
    }

    fun downloadAiCore() {
        if (_state.value.download?.running == true) return
        viewModelScope.launch {
            val id = models.enqueueAiDownload()
            val ok = models.watchDownload(id, "LOCAL AI CORE") {
                _state.value = _state.value.copy(download = it)
            }
            _state.value = _state.value.copy(
                aiReady = models.aiReady(),
                status = if (ok) "LOCAL CORE DOWNLOADED" else "DOWNLOAD ERROR"
            )
        }
    }

    fun downloadVoicePack(lang: VoiceLanguage) {
        if (_state.value.download?.running == true) return
        viewModelScope.launch {
            val id = models.enqueueVoiceDownload(lang)
            val ok = models.watchDownload(id, "VOICE // ${lang.title}") {
                _state.value = _state.value.copy(download = it)
            }
            if (ok) {
                _state.value = _state.value.copy(
                    download = DownloadProgress(true, 100, "INSTALLING VOICE // ${lang.title}")
                )
                try {
                    models.installVoiceZip(lang)
                    _state.value = _state.value.copy(
                        download = DownloadProgress(
                            false, 100, "VOICE // ${lang.title}", success = true
                        ),
                        status = "VOICE READY // ${lang.title}"
                    )
                } catch (e: Throwable) {
                    _state.value = _state.value.copy(
                        download = DownloadProgress(
                            false, 100, "VOICE // ${lang.title}",
                            error = e.message ?: "Install failed"
                        )
                    )
                }
            }
        }
    }

    fun voiceReady(lang: VoiceLanguage): Boolean = models.voiceReady(lang)

    override fun onCleared() {
        super.onCleared()
        tts.shutdown()
        voice.release()
        viewModelScope.launch(Dispatchers.IO) {
            ai.unload()
        }
    }
}

package com.arachne.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.UUID

enum class VoiceStyle(val title: String, val rate: Float, val pitch: Float) {
    CORE("Core", 0.96f, 0.92f),
    CALM("Calm", 0.88f, 0.96f),
    TACTICAL("Tactical", 1.03f, 0.84f)
}

class TtsEngine(context: Context) : TextToSpeech.OnInitListener {

    private var ready = false
    private var style = VoiceStyle.CORE

    private val tts = TextToSpeech(context.applicationContext, this)

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
    }

    fun setStyle(newStyle: VoiceStyle) {
        style = newStyle
    }

    fun stop() {
        tts.stop()
    }

    fun isSpeaking(): Boolean = tts.isSpeaking

    fun speak(text: String) {
        if (!ready || text.isBlank()) return

        val locale = detectLocale(text)
        if (tts.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE) {
            tts.language = locale
        }

        tts.setSpeechRate(style.rate)
        tts.setPitch(style.pitch)
        tts.speak(
            text,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "arachne-${UUID.randomUUID()}"
        )
    }

    private fun detectLocale(text: String): Locale {
        val low = text.lowercase()

        val germanHits = listOf(
            " und ", " ich ", " nicht ", " das ", " ist ", " du ",
            "wie ", "warum ", "kannst ", "danke "
        ).count { low.contains(it) }

        val englishHits = listOf(
            " the ", " and ", " you ", " is ", " are ", " why ",
            "how ", "can ", "thanks ", "hello "
        ).count { low.contains(it) }

        return when {
            germanHits >= 2 && germanHits > englishHits -> Locale.GERMAN
            englishHits >= 2 -> Locale.ENGLISH
            else -> Locale("es", "ES")
        }
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }
}

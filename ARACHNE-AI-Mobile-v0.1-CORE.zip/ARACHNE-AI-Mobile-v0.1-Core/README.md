# A.R.A.C.H.N.E AI Mobile v0.1 — CORE

First mobile-only A.R.A.C.H.N.E AI build.

## Scope of v0.1

Included:
- fully local text AI
- normal conversation
- Spanish / English / German
- persistent local memory
- "remember X" / "forget X"
- four personalities
- offline voice recognition
- local Android TTS
- manual barge-in: MIC stops A.R.A.C.H.N.E speaking immediately
- local chat history
- LAB screen
- zero API keys
- zero subscription
- zero per-message cost

Deferred:
- PDF / RAG
- image vision
- wake word
- automatic barge-in without touching MIC
- PC sync
- Android system automation

## Hardware profile

Designed initially for:
- ARM64 Android phone
- 8 GB real RAM
- balanced CPU-only inference
- Qwen3 1.7B Q4_K_M
- 2048-token context
- 4 CPU threads

## Local AI model

The APK does NOT contain the large model.

Open `LAB` and select:

`DOWNLOAD LOCAL CORE`

The app downloads:

`Qwen3-1.7B-Q4_K_M.gguf`

from the public ggml-org model repository.

The model is stored inside the app's external private files area.

After download, AI inference itself is local.

## Voice

Voice recognition uses Vosk.

Three optional offline packs are available in LAB:
- Español — `vosk-model-small-es-0.42`
- English — `vosk-model-small-en-us-0.15`
- Deutsch — `vosk-model-small-de-0.15`

Only download the ones you want.

Select the voice input language in LAB before talking.

Android TextToSpeech is used for spoken responses. The app has three sound profiles:
- Core
- Calm
- Tactical

## Memory examples

Spanish:
`Recuerda que mi color favorito es azul.`

English:
`Remember that I prefer short answers.`

German:
`Merk dir, dass ich morgen Deutsch lernen muss.`

Forget:
`Olvida mi color favorito.`
`Forget short answers.`
`Vergiss morgen Deutsch lernen.`

Long-term memory lives in the app's private SQLite database.

## Personalities

- A.R.A.C.H.N.E
- Casual
- Tactical
- Study

They alter the system prompt, not only the visual appearance.

## Build APK on GitHub

1. Create a new GitHub repository.
2. Upload ALL files and folders from this ZIP to the root of the repository.
3. Open the repository's `Actions` tab.
4. Run `Build A.R.A.C.H.N.E AI APK`.
5. Download artifact:
   `ARACHNE-AI-Mobile-v0.1-debug`
6. Extract it and install `app-debug.apk`.

The workflow uses:
- JDK 17
- Android SDK 36
- Gradle 8.13

## First test order

1. Install APK.
2. Grant microphone permission.
3. Open LAB.
4. Download `LOCAL AI CORE`.
5. Download `Español` voice pack.
6. Return to Chat.
7. Try:
   `Hola A.R.A.C.H.N.E. Preséntate.`
8. Try:
   `Recuerda que esta es nuestra primera prueba móvil.`
9. Ask:
   `¿Qué recuerdas sobre nuestra primera prueba móvil?`
10. Tap MIC and speak in Spanish.

## Privacy

No paid AI/cloud API is configured.

Internet permission exists only because the app must download the AI and speech
models initially. Conversation inference and Vosk speech recognition operate
on the phone after their model files are installed.

## Current v0.1 limitation

The free llama.cpp Android AAR used here returns the full response after
generation rather than streaming individual tokens. This is intentionally
kept free. The UI therefore shows THINKING while the response is generated.

PDFs and vision are intentionally deferred until the conversational/voice core
is stable.

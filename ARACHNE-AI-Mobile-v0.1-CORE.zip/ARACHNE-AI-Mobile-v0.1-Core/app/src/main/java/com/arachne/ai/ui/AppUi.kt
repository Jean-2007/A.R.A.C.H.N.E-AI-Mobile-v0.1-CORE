package com.arachne.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arachne.ai.core.Personality
import com.arachne.ai.core.VoiceLanguage
import com.arachne.ai.voice.VoiceStyle
import kotlinx.coroutines.launch

private val Bg = Color(0xFF06070B)
private val Panel = Color(0xFF0D111B)
private val Panel2 = Color(0xFF111725)
private val Blue = Color(0xFF4388FF)
private val Red = Color(0xFFE93458)
private val Text = Color(0xFFF3F6FC)
private val Muted = Color(0xFF8995AA)

enum class MobilePage { CHAT, MEMORY, LAB }

@Composable
fun ArachneApp(vm: ChatViewModel) {
    val state by vm.state.collectAsState()
    var page by remember { mutableStateOf(MobilePage.CHAT) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Blue,
            secondary = Red,
            onBackground = Text,
            onSurface = Text
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF080B12)) {
                    NavigationBarItem(
                        selected = page == MobilePage.CHAT,
                        onClick = { page = MobilePage.CHAT },
                        icon = { Icon(Icons.Default.Chat, null) },
                        label = { Text("Chat") }
                    )
                    NavigationBarItem(
                        selected = page == MobilePage.MEMORY,
                        onClick = { page = MobilePage.MEMORY },
                        icon = { Icon(Icons.Default.Memory, null) },
                        label = { Text("Memory") }
                    )
                    NavigationBarItem(
                        selected = page == MobilePage.LAB,
                        onClick = { page = MobilePage.LAB },
                        icon = { Icon(Icons.Default.Science, null) },
                        label = { Text("LAB") }
                    )
                }
            }
        ) { pad ->
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(pad)
                    .background(Bg)
            ) {
                when (page) {
                    MobilePage.CHAT -> ChatPage(state, vm)
                    MobilePage.MEMORY -> MemoryPage(state, vm)
                    MobilePage.LAB -> LabPage(state, vm)
                }
            }
        }
    }
}

@Composable
private fun Header(state: UiState) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArachneOrb(
            thinking = state.busy,
            listening = state.listening,
            modifier = Modifier.size(54.dp)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "A.R.A.C.H.N.E",
                color = Text,
                fontWeight = FontWeight.Black,
                fontSize = 19.sp,
                letterSpacing = 2.sp
            )
            Text(
                state.status,
                color = if (state.listening) Red else Blue,
                fontSize = 10.sp,
                letterSpacing = 1.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Surface(
            color = if (state.aiReady) Blue.copy(alpha = .12f) else Red.copy(alpha = .12f),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (state.aiReady) Blue.copy(alpha = .45f) else Red.copy(alpha = .4f)
            )
        ) {
            Text(
                if (state.aiReady) "LOCAL" else "NO CORE",
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                color = if (state.aiReady) Blue else Red,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun ArachneOrb(
    thinking: Boolean,
    listening: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (thinking || listening) 900 else 2200, easing = LinearEasing)
        ),
        label = "angle"
    )

    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val radius = size.minDimension * .40f
        drawCircle(Color(0xFF0B1020), radius)
        drawArc(
            color = if (listening) Red else Blue,
            startAngle = angle,
            sweepAngle = 210f,
            useCenter = false,
            topLeft = Offset(c.x - radius, c.y - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
            style = Stroke(width = 4f, cap = StrokeCap.Round)
        )
        drawArc(
            color = Red.copy(alpha = .75f),
            startAngle = -angle * .7f,
            sweepAngle = 140f,
            useCenter = false,
            topLeft = Offset(c.x - radius * .72f, c.y - radius * .72f),
            size = androidx.compose.ui.geometry.Size(radius * 1.44f, radius * 1.44f),
            style = Stroke(width = 2.3f, cap = StrokeCap.Round)
        )
        drawCircle(
            (if (listening) Red else Blue).copy(alpha = .22f),
            radius = radius * .52f
        )
    }
}

@Composable
private fun ChatPage(state: UiState, vm: ChatViewModel) {
    Column(Modifier.fillMaxSize()) {
        Header(state)

        PersonalityBar(state.personality, vm::setPersonality)

        val listState = rememberLazyListState()
        val scope = rememberCoroutineScope()

        LaunchedEffect(state.messages.size) {
            if (state.messages.isNotEmpty()) {
                scope.launch { listState.animateScrollToItem(state.messages.lastIndex) }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.messages) { msg ->
                MessageBubble(msg)
            }

            if (state.listening && state.voicePartial.isNotBlank()) {
                item {
                    Text(
                        "LISTENING › ${state.voicePartial}",
                        color = Red,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            if (state.busy) {
                item {
                    Text(
                        "A.R.A.C.H.N.E is thinking locally…",
                        color = Blue,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }

        Composer(state, vm)
    }
}

@Composable
private fun PersonalityBar(
    selected: Personality,
    onChange: (Personality) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("PERSONALITY", color = Muted, fontSize = 9.sp, letterSpacing = 1.3.sp)
        Spacer(Modifier.weight(1f))
        Box {
            TextButton(onClick = { expanded = true }) {
                Text(selected.title, color = Blue, fontSize = 11.sp)
                Icon(Icons.Default.ArrowDropDown, null, tint = Blue)
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                Personality.entries.forEach {
                    DropdownMenuItem(
                        text = { Text(it.title) },
                        onClick = {
                            expanded = false
                            onChange(it)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(msg: ChatBubble) {
    val user = msg.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (user) Blue.copy(alpha = .16f) else Panel,
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (user) 18.dp else 5.dp,
                bottomEnd = if (user) 5.dp else 18.dp
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (user) Blue.copy(alpha = .28f) else Color.White.copy(alpha = .07f)
            ),
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Column(Modifier.padding(13.dp)) {
                Text(
                    if (user) "JEAN" else "A.R.A.C.H.N.E",
                    color = if (user) Blue else Red,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
                Spacer(Modifier.height(5.dp))
                Text(msg.text, color = Text, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
    }
}

@Composable
private fun Composer(state: UiState, vm: ChatViewModel) {
    var text by remember { mutableStateOf("") }

    Surface(
        color = Color(0xFF090C13),
        tonalElevation = 4.dp
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = vm::startOrStopListening,
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = if (state.listening) Red.copy(alpha = .20f)
                    else Panel2
                )
            ) {
                Icon(
                    if (state.listening) Icons.Default.Stop else Icons.Default.Mic,
                    contentDescription = "Voice",
                    tint = if (state.listening) Red else Blue
                )
            }

            Spacer(Modifier.width(8.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Talk to A.R.A.C.H.N.E…", color = Muted) },
                singleLine = false,
                maxLines = 4,
                shape = RoundedCornerShape(16.dp),
                enabled = !state.busy
            )

            Spacer(Modifier.width(8.dp))

            FilledIconButton(
                onClick = {
                    val send = text
                    text = ""
                    vm.send(send)
                },
                enabled = text.isNotBlank() && !state.busy,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Blue
                )
            ) {
                Icon(Icons.Default.Send, "Send")
            }
        }
    }
}

@Composable
private fun MemoryPage(state: UiState, vm: ChatViewModel) {
    var text by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        Header(state)

        Column(Modifier.padding(horizontal = 16.dp)) {
            Text(
                "MEMORY CORE",
                color = Text,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp
            )
            Text(
                "Only memories explicitly stored here are considered long-term memory.",
                color = Muted,
                fontSize = 11.sp
            )

            Spacer(Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Add a memory…") },
                    singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                FilledIconButton(
                    onClick = {
                        vm.addMemory(text)
                        text = ""
                    },
                    enabled = text.isNotBlank()
                ) {
                    Icon(Icons.Default.Add, null)
                }
            }

            Spacer(Modifier.height(12.dp))
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (state.memories.isEmpty()) {
                item {
                    Text(
                        "No long-term memories yet.\nTry: “Recuerda que…”",
                        color = Muted,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            items(state.memories, key = { it.id }) { memory ->
                Surface(
                    color = Panel,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        Color.White.copy(alpha = .06f)
                    )
                ) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Memory, null, tint = Blue)
                        Spacer(Modifier.width(10.dp))
                        Text(memory.text, color = Text, modifier = Modifier.weight(1f))
                        IconButton(onClick = { vm.deleteMemory(memory.id) }) {
                            Icon(Icons.Default.DeleteOutline, null, tint = Red)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LabPage(state: UiState, vm: ChatViewModel) {
    Column(Modifier.fillMaxSize()) {
        Header(state)

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LabCard("LOCAL AI CORE") {
                    StatusRow("Model", "Qwen3 1.7B Q4_K_M")
                    StatusRow("Engine", "llama.cpp / CPU NEON")
                    StatusRow("Context", "2048")
                    StatusRow(
                        "Status",
                        if (state.aiReady) "READY" else "NOT INSTALLED",
                        if (state.aiReady) Blue else Red
                    )

                    if (!state.aiReady) {
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = vm::downloadAiCore,
                            enabled = state.download?.running != true,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Download, null)
                            Spacer(Modifier.width(8.dp))
                            Text("DOWNLOAD LOCAL CORE")
                        }
                    }
                }
            }

            state.download?.let { d ->
                item {
                    LabCard(d.label) {
                        LinearProgressIndicator(
                            progress = { d.progress / 100f },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            d.error ?: "${d.progress}%",
                            color = if (d.error != null) Red else Muted,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            item {
                LabCard("VOICE CORE") {
                    Text(
                        "Voice recognition is local. Download only the languages you want.",
                        color = Muted,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(8.dp))

                    VoiceLanguage.entries.forEach { lang ->
                        val ready = vm.voiceReady(lang)
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = state.voiceLanguage == lang,
                                onClick = { vm.setVoiceLanguage(lang) }
                            )
                            Text(lang.title, color = Text, modifier = Modifier.weight(1f))
                            if (ready) {
                                Text("READY", color = Blue, fontSize = 9.sp)
                            } else {
                                TextButton(
                                    onClick = { vm.downloadVoicePack(lang) },
                                    enabled = state.download?.running != true
                                ) {
                                    Text("DOWNLOAD", fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
            }

            item {
                LabCard("VOICE OUTPUT") {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Speak replies", color = Text, modifier = Modifier.weight(1f))
                        Switch(
                            checked = state.voiceOutput,
                            onCheckedChange = { vm.toggleVoiceOutput() }
                        )
                    }

                    Text("VOICE STYLE", color = Muted, fontSize = 9.sp)
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        VoiceStyle.entries.forEach { style ->
                            FilterChip(
                                selected = state.voiceStyle == style,
                                onClick = { vm.setVoiceStyle(style) },
                                label = { Text(style.title) }
                            )
                        }
                    }

                    Text(
                        "Pressing MIC while A.R.A.C.H.N.E is speaking stops her immediately and starts listening.",
                        color = Muted,
                        fontSize = 10.sp
                    )
                }
            }

            item {
                LabCard("PERFORMANCE") {
                    StatusRow(
                        "Last speed",
                        if (state.tokensPerSecond > 0)
                            "%.2f tok/s".format(state.tokensPerSecond)
                        else "--"
                    )
                    StatusRow("Mode", "100% LOCAL")
                    StatusRow("Cloud API", "DISABLED", Blue)
                }
            }

            item {
                LabCard("CONVERSATION") {
                    OutlinedButton(
                        onClick = vm::clearConversation,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.DeleteSweep, null)
                        Spacer(Modifier.width(8.dp))
                        Text("CLEAR CHAT HISTORY")
                    }
                    Text(
                        "Long-term memories are not deleted by this button.",
                        color = Muted,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun LabCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = Panel,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Color.White.copy(alpha = .07f)
        )
    ) {
        Column(
            Modifier.padding(15.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                title,
                color = Blue,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.3.sp
            )
            content()
        }
    }
}

@Composable
private fun StatusRow(
    key: String,
    value: String,
    valueColor: Color = Text
) {
    Row(Modifier.fillMaxWidth()) {
        Text(key, color = Muted, fontSize = 11.sp)
        Spacer(Modifier.weight(1f))
        Text(value, color = valueColor, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

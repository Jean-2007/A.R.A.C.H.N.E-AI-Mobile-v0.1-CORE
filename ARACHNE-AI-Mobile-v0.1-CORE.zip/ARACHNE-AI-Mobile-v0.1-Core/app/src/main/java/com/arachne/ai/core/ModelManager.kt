package com.arachne.ai.core

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipInputStream

data class DownloadProgress(
    val running: Boolean,
    val progress: Int,
    val label: String,
    val success: Boolean = false,
    val error: String? = null
)

enum class VoiceLanguage(
    val code: String,
    val title: String,
    val folder: String,
    val zipName: String,
    val url: String
) {
    ES(
        "es", "Español",
        "vosk-model-small-es-0.42",
        "vosk-model-small-es-0.42.zip",
        "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip"
    ),
    EN(
        "en", "English",
        "vosk-model-small-en-us-0.15",
        "vosk-model-small-en-us-0.15.zip",
        "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    ),
    DE(
        "de", "Deutsch",
        "vosk-model-small-de-0.15",
        "vosk-model-small-de-0.15.zip",
        "https://alphacephei.com/vosk/models/vosk-model-small-de-0.15.zip"
    )
}

class ModelManager(private val context: Context) {

    companion object {
        const val AI_FILE = "Qwen3-1.7B-Q4_K_M.gguf"
        const val AI_URL =
            "https://huggingface.co/ggml-org/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf"
    }

    private val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun aiModelFile(): File =
        File(context.getExternalFilesDir(null), "models/$AI_FILE")

    fun aiReady(): Boolean = aiModelFile().exists() && aiModelFile().length() > 500_000_000L

    fun voiceModelDir(lang: VoiceLanguage): File =
        File(context.filesDir, "voice/${lang.folder}")

    fun voiceReady(lang: VoiceLanguage): Boolean =
        voiceModelDir(lang).resolve("conf/model.conf").exists() ||
            voiceModelDir(lang).resolve("am/final.mdl").exists()

    fun enqueueAiDownload(): Long {
        aiModelFile().parentFile?.mkdirs()
        if (aiModelFile().exists()) aiModelFile().delete()

        val request = DownloadManager.Request(Uri.parse(AI_URL))
            .setTitle("A.R.A.C.H.N.E Local Core")
            .setDescription("Qwen3 1.7B Q4_K_M")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalFilesDir(context, null, "models/$AI_FILE")

        return dm.enqueue(request)
    }

    fun enqueueVoiceDownload(lang: VoiceLanguage): Long {
        val target = File(context.getExternalFilesDir(null), "voice-downloads/${lang.zipName}")
        target.parentFile?.mkdirs()
        if (target.exists()) target.delete()

        val request = DownloadManager.Request(Uri.parse(lang.url))
            .setTitle("A.R.A.C.H.N.E Voice — ${lang.title}")
            .setDescription("Offline speech recognition")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setDestinationInExternalFilesDir(
                context, null, "voice-downloads/${lang.zipName}"
            )

        return dm.enqueue(request)
    }

    suspend fun watchDownload(
        id: Long,
        label: String,
        onProgress: (DownloadProgress) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        while (true) {
            val q = DownloadManager.Query().setFilterById(id)
            dm.query(q).use { c ->
                if (!c.moveToFirst()) {
                    onProgress(DownloadProgress(false, 0, label, error = "Download disappeared"))
                    return@withContext false
                }

                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val downloaded = c.getLong(
                    c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                )
                val total = c.getLong(
                    c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                )
                val pct = if (total > 0) ((downloaded * 100L) / total).toInt() else 0

                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        onProgress(DownloadProgress(false, 100, label, success = true))
                        return@withContext true
                    }
                    DownloadManager.STATUS_FAILED -> {
                        val reason = c.getInt(
                            c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)
                        )
                        onProgress(
                            DownloadProgress(
                                false, pct, label,
                                error = "Download failed ($reason)"
                            )
                        )
                        return@withContext false
                    }
                    else -> onProgress(DownloadProgress(true, pct, label))
                }
            }
            delay(700)
        }
        @Suppress("UNREACHABLE_CODE")
        false
    }

    suspend fun installVoiceZip(lang: VoiceLanguage) = withContext(Dispatchers.IO) {
        val zipFile = File(
            context.getExternalFilesDir(null),
            "voice-downloads/${lang.zipName}"
        )
        if (!zipFile.exists()) error("Voice package not found")

        val voiceRoot = File(context.filesDir, "voice")
        voiceRoot.mkdirs()

        ZipInputStream(FileInputStream(zipFile)).use { zis ->
            while (true) {
                val entry = zis.nextEntry ?: break
                val out = File(voiceRoot, entry.name)

                val canonicalRoot = voiceRoot.canonicalPath + File.separator
                val canonicalOut = out.canonicalPath
                require(canonicalOut.startsWith(canonicalRoot)) {
                    "Unsafe zip entry"
                }

                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { dest ->
                        zis.copyTo(dest)
                    }
                }
                zis.closeEntry()
            }
        }

        zipFile.delete()
    }
}

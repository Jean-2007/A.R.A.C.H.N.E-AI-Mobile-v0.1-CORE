package com.arachne.ai.core

import android.content.Context
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import dev.ffmpegkit.llama.LlamaModel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class AiReply(
    val text: String,
    val tokensPerSecond: Float
)

class AiEngine(
    private val context: Context,
    private val memory: MemoryStore,
    private val models: ModelManager
) {
    private val mutex = Mutex()
    private var loadedModel: LlamaModel? = null

    suspend fun unload() = mutex.withLock {
        loadedModel?.let(Llama::releaseModel)
        loadedModel = null
    }

    private suspend fun ensureLoaded(): LlamaModel {
        loadedModel?.takeIf { it.isLoaded }?.let { return it }

        val file = models.aiModelFile()
        if (!models.aiReady()) {
            error("LOCAL_MODEL_MISSING")
        }

        val config = LlamaConfig(
            contextSize = 2048,
            threads = 4,
            gpuLayers = 0,
            temperature = 0.72f,
            topP = 0.9f,
            topK = 40
        )

        return Llama.loadModel(file.absolutePath, config).also {
            loadedModel = it
        }
    }

    suspend fun reply(
        userText: String,
        personality: Personality
    ): AiReply = mutex.withLock {
        val model = ensureLoaded()

        val memories = memory.relevantMemories(userText, 6)
        val recent = memory.recentMessages(8)

        val memoryBlock = if (memories.isEmpty()) {
            "No relevant long-term memories were retrieved."
        } else {
            memories.joinToString("\n") { "- ${it.text}" }
        }

        val historyBlock = if (recent.isEmpty()) {
            "No recent conversation."
        } else {
            recent.joinToString("\n") {
                "${it.role.uppercase()}: ${it.text}"
            }
        }

        val systemPrompt = """
            ${personality.prompt}

            MEMORY RULES:
            - The following memories are local records explicitly stored by the user.
            - Use them only when relevant.
            - Never invent additional memories.
            - If the user asks you to remember or forget something, the app itself handles it.

            RELEVANT LONG-TERM MEMORY:
            $memoryBlock

            RECENT CONVERSATION:
            $historyBlock
        """.trimIndent()

        val result = Llama.complete(
            model = model,
            prompt = userText,
            systemPrompt = systemPrompt,
            maxTokens = 320
        )

        AiReply(
            text = result.text.trim(),
            tokensPerSecond = result.tokensPerSecond
        )
    }
}

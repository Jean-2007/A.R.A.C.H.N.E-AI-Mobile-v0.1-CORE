# A.R.A.C.H.N.E AI Mobile — Architecture

UI (Jetpack Compose)
        |
        v
ChatViewModel
   |       |       |
   v       v       v
AiEngine  Memory  Voice
   |       |       |
llama.cpp SQLite  Vosk + Android TTS
   |
Qwen3 1.7B GGUF

## No unrestricted tool execution

v0.1 is deliberately a conversational assistant, not a shell.
No arbitrary terminal/system command execution is included.

## Memory policy

Long-term memory is explicit and inspectable:
- user says "remember..."
- user manually adds memory
- user can delete every memory in MEMORY CORE

A.R.A.C.H.N.E must not claim stored memory when no matching item exists.

## Voice interruption

In v0.1:
- TTS speaking
- user taps MIC
- TTS stops immediately
- offline Vosk starts listening

Automatic always-listening barge-in is deferred because it would consume more
battery and requires more careful microphone/VAD lifecycle design.
